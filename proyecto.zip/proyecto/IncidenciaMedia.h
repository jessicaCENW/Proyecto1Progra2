//
// Created by ansat on 30/4/2026.
//

#ifndef PROYECTO_INCIDENCIAMEDIA_H
#define PROYECTO_INCIDENCIAMEDIA_H
#include "Equipo.h"
#include "Incidencia.h"


class IncidenciaMedia: public Incidencia {
    public:
        void gradoIncidencia(Equipo* a) override {
            a->aumentarCriticidad(2);
        }
    string getTipo() override {
        return "Media";
    }
};


#endif //PROYECTO_INCIDENCIAMEDIA_H
//
// Created by ansat on 30/4/2026.
//

#ifndef PROYECTO_INCIDENCIAGRAVE_H
#define PROYECTO_INCIDENCIAGRAVE_H
#include "Incidencia.h"
#include "Equipo.h"


class IncidenciaGrave: public Incidencia {
public:
    void gradoIncidencia(Equipo* a) override {
        a->aumentarCriticidad(3);
    }
    string getTipo() override {
        return "Grave";
    }
};


#endif //PROYECTO_INCIDENCIAGRAVE_H
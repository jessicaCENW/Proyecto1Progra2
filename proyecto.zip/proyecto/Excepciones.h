#ifndef PROYECTO_EXCEPCIONES_H
#define PROYECTO_EXCEPCIONES_H
#include <exception>
#include <string>
using namespace std;



class Excepciones : public exception{
protected:
    string mensaje;

public:
    Excepciones(string m) {
        mensaje = m;
    }

    const char* what() const noexcept override {
        return mensaje.c_str();
    }

};



class ExcepcionIndice : public Excepciones {
public:
    ExcepcionIndice() : Excepciones("Indice fuera de rango") {}
};


class ExcepcionIncidencias : public Excepciones {
public:
    ExcepcionIncidencias(): Excepciones("Limite de incidencias alcanzado") {}
};


class ExcepcionStrategy : public Excepciones {
public:
    ExcepcionStrategy(): Excepciones("Strategy no definida") {}
};


#endif //PROYECTO_EXCEPCIONES_H
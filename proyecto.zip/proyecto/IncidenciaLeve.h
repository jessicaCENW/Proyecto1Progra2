//
// Created by ansat on 30/4/2026.
//

#ifndef PROYECTO_INCIDENCIALEVE_H
#define PROYECTO_INCIDENCIALEVE_H
#include "Equipo.h"
#include "Incidencia.h"

class IncidenciaLeve: public Incidencia {
public:
    void gradoIncidencia(Equipo* a) override {
        a->aumentarCriticidad(1);
    }
    string getTipo() override {
        return "Leve";
    }
};


#endif //PROYECTO_INCIDENCIALEVE_H
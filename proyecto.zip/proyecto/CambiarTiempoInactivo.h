#ifndef PROYECTO_CAMBIARTIEMPOINACTIVO_H
#define PROYECTO_CAMBIARTIEMPOINACTIVO_H
#include "Equipo.h"


class CambiarTiempoInactivo {
public:
    virtual void cambiarTiempo(Equipo& a) = 0;
};


#endif //PROYECTO_CAMBIARTIEMPOINACTIVO_H
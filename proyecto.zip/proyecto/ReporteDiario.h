#ifndef PROYECTO_REPORTEDIARIO_H
#define PROYECTO_REPORTEDIARIO_H
#pragma once
#include "Reporte.h"
#include "ColeccionEquipos.h"
#include <sstream>

class ReporteDiario : public Reporte {
private:
    int dia;
    ColeccionEquipos* equipos;
    string* incidencias;
    int cantidadIncidencias;


public:
    ReporteDiario(int d, ColeccionEquipos* eq,
                 string inc[], int cant) {
        dia = d;
        equipos = eq;
        incidencias = inc;
        cantidadIncidencias = cant;
    }

    string generar() override {
        stringstream ss;

        ss << "Dia " << dia << "\n";


        ss << "Incidencias del dia:\n";
        for (int i = 0; i < cantidadIncidencias; i++) {
            ss << incidencias[i] << "\n";
        }


        ss << "\nTop 3:\n";
        for (int i = 0; i < 3; i++) {

            Equipo* e = equipos->getEquipo(i);

            ss << "Equipo " << e->getId()
               << " | Prioridad: " << e->CalcularPrioridad()
               << " | Incidencias: " << e->incidenciasToString()
               << "\n";
        }


        ss << "\nPendientes:\n";
        for (int i = 3; i < equipos->getCantidad(); i++) {

            Equipo* e = equipos->getEquipo(i);

            ss << "Equipo " << e->getId()
               << " | Prioridad: " << e->CalcularPrioridad()
               << " | Incidencias: " << e->incidenciasToString()
               << "\n";
        }

        return ss.str();
    }
};

#endif //PROYECTO_REPORTEDIARIO_H
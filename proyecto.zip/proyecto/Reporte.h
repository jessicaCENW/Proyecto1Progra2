#ifndef PROYECTO_REPORTE_H
#define PROYECTO_REPORTE_H
#pragma once
#include <string>
using namespace std;



class Reporte {
    public:
    virtual string generar() = 0;
    virtual ~Reporte() {}
};


#endif //PROYECTO_REPORTE_H
//
// Created by ansat on 29/4/2026.
//

#ifndef PROYECTO_AUMENTARTIEMPOINACTIVO_H
#define PROYECTO_AUMENTARTIEMPOINACTIVO_H
#include "CambiarTiempoInactivo.h"
#include "Equipo.h"


class AumentarTiempoInactivo: public CambiarTiempoInactivo {
    public:
        void cambiarTiempo(Equipo& a) override{
            a.SetTiempoInactivo(a.GetTiempoInactivo() + 1);
        }
};


#endif //PROYECTO_AUMENTARTIEMPOINACTIVO_H
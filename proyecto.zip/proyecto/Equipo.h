//
// Created by ansat on 23/4/2026.
//

#ifndef PROYECTO_EQUIPO_H
#define PROYECTO_EQUIPO_H
#pragma once
#include <string>
using namespace std;
#include "Incidencia.h"

class Equipo
{
private:
    string id;
    int criticidad;
    int timpoInactivo;
    Incidencia* incP[10];

public:
    Equipo(const string& id, int criticidad, int timpoInactivo);
    Equipo();



};


#endif //PROYECTO_EQUIPO_H
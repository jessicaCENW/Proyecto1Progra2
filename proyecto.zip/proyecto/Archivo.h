#ifndef PROYECTO_ARCHIVO_H
#define PROYECTO_ARCHIVO_H
#include <fstream>
#include <string>
using namespace std;

class Archivo {
public:
    static void guardar(string texto, int dia) {

        string nombre = "dia_" + to_string(dia) + ".txt";

        ofstream archivo(nombre);
        archivo << texto;
        archivo.close();
    }
};


#endif //PROYECTO_ARCHIVO_H
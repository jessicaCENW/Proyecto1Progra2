#include "Equipo.h"

Equipo::Equipo(const string& id, int criticidad, int timpoInactivo) {
    this->id = id;
    this->criticidad = criticidad;
    this->timpoInactivo = timpoInactivo;

}

Equipo::Equipo()
{
    this->id = "";
    this->criticidad = 0;
    this->timpoInactivo = 0;

}
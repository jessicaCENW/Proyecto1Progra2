//
// Created by ansat on 30/4/2026.
//

#include "IncidenciaMedia.h"
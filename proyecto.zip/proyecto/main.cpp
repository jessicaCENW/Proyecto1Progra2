#include <iostream>
using namespace std;
#include <iostream>
#include "Simulador.h"
#include "Excepciones.h"

int main() {
    try {
        Simulador simulacion;
        simulacion.ejecutar();

        cout << "Simulacion completada correctamente.\n";

    } catch (Excepciones& e) {
        cout << "Error del sistema: " << e.what() << endl;

    } catch (...) {
        cout << "Error desconocido.\n";
    }

    return 0;


    return 0;
}

//
// Created by ansat on 23/4/2026.
//

#include "Incidencia.h"
#include <random>
using namespace std;
#ifndef PROYECTO_EVENTOSDIARIOS_H
#define PROYECTO_EVENTOSDIARIOS_H
#include "CambiarTiempoInactivo.h"
using namespace std;
#include "Equipo.h"
#include "ColeccionEquipos.h"
#include <vector>
#include <string>
#include <random>
#include "Incidencia.h"
#include "AumentarTiempoInactivo.h"
#include "ResetTiempo.h"
#include "CambioTiempo.h"


class EventosDiarios {
public:
        void desgaste(Equipo& a) {
                random_device rd;
                mt19937 gen(rd());
                uniform_real_distribution<> dist(0.2, 1.5);

                a.aumentarCriticidad(dist(gen));
        }
        vector<string> incidenciasDelDia;
        void GenerarIncidencia(Equipo& a) {
                if (a.getContador()<10) {
                         random_device rd;
                        mt19937 gen(rd());
                        uniform_int_distribution<> dist(1, 7);
                        if (dist(gen)==1) {
                                a.agregarIncidencia();

                                Incidencia* inc = a.getIncidencia(a.getContador() - 1);

                                string texto = "Equipo " + to_string(a.getId()) +
                                               " -> " + inc->getTipo();

                                incidenciasDelDia.push_back(texto);
                        }
                }
        }
        void Tiempo(Equipo& a) {
                CambioTiempo c;
                ResetTiempo r;
                AumentarTiempoInactivo t;
                random_device rd;
                mt19937 gen(rd());
                uniform_int_distribution<> dist(1, 5);
                if (dist(gen)==1) {
                        c.setCambio(&r);
                        c.CambiarTiempo(a);
                }
                else {
                        c.setCambio(&t);
                        c.CambiarTiempo(a);
                }
        }
        void ordenarcoleccion(ColeccionEquipos& b) {
                int n = b.getCantidad();
                if (n > 1) {
                        mergeSort(b, 0, n - 1);
                }
        }
        void mergeSort(ColeccionEquipos& b, int izq, int der) {
                if (izq < der) {
                        int medio = (der + izq) / 2;
                        mergeSort(b, izq, medio);
                        mergeSort(b, medio + 1, der);
                        merge(b, izq, medio, der);
                }

        }

        void merge(ColeccionEquipos& b, int izq, int medio, int der) {
                int n1 = medio - izq + 1;
                int n2 = der - medio;

                Equipo** L = new Equipo*[n1];
                Equipo** R = new Equipo*[n2];

                for (int i = 0; i < n1; i++) {
                        L[i] = b.getEquipo(izq + i);
                }
                for (int j = 0; j < n2; j++) {
                        R[j] = b.getEquipo(medio + 1 + j);
                }

                int i = 0, j = 0, k = izq;
                while (i < n1 && j < n2) {
                        if (L[i]->CalcularPrioridad() >= R[j]->CalcularPrioridad()) {
                                b.getEquipo(k) = L[i];
                                i++;
                        } else {
                                b.getEquipo(k) = R[j];
                                j++;
                        }
                        k++;
                }
                while (i < n1) {
                        b.getEquipo(k) = L[i];
                        i++;
                        k++;
                }
                while (j < n2) {
                        b.getEquipo(k) = R[j];
                        j++;
                        k++;
                }

                delete[] L;
                delete[] R;
        }

};


#endif //PROYECTO_EVENTOSDIARIOS_H
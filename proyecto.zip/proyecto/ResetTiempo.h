//
// Created by ansat on 29/4/2026.
//

#ifndef PROYECTO_RESETTIEMPO_H
#define PROYECTO_RESETTIEMPO_H
#include "CambiarTiempoInactivo.h"
#include "Equipo.h"


class ResetTiempo: public CambiarTiempoInactivo{
    public:
        void cambiarTiempo(Equipo& a) override{
            a.SetTiempoInactivo(0);
        }
};


#endif //PROYECTO_RESETTIEMPO_H
//
// Created by ansat on 30/4/2026.
//

#ifndef PROYECTO_REPORTEACUMULADO_H
#define PROYECTO_REPORTEACUMULADO_H
#pragma once
#include "Reporte.h"
#include <sstream>

class ReporteAcumulado : public Reporte {
private:
    string dias[30];
    int contador = 0;

public:
    void agregarDia(string texto) {
        if (contador < 30) {
            dias[contador] = texto;
            contador++;
        }
    }

    string generar() override {
        stringstream ss;

        ss << "===== REPORTE ACUMULADO =====\n";

        for (int i = 0; i < contador; i++) {
            ss << dias[i] << "\n";
        }

        return ss.str();
    }
};


#endif //PROYECTO_REPORTEACUMULADO_H
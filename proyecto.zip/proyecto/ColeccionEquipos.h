#ifndef PROYECTO_COLECCIONEQUIPOS_H
#define PROYECTO_COLECCIONEQUIPOS_H
using namespace std;
#include "Equipo.h"
#include <iostream>
#include "Excepciones.h"



class ColeccionEquipos {
private:
    Equipo* equipo[100];
    int cant=0;

public:

    void llenar() {
        for (int i=0; i<100; i++) {
            equipo[i]=new Equipo();
            equipo[i]->setId(i+1);
            cant++;
        }
    }
    void setEquipo(int i, Equipo* e) {
        equipo[i]=e;
    }
    Equipo*& getEquipo(int i) {
        if (i < 0 || i >= cant) {
            throw ExcepcionIndice();
        }
        return equipo[i];
    }
    int getCantidad() {
        return cant;
    }
    ~ColeccionEquipos() {
        for (int i = 0; i < cant; i++) {
            delete equipo[i];
        }
    }
    void mostrar() {
        for (int i=0; i<100; i++) {
            cout<<equipo[i]->tostring()<<endl;
        }
    }


};


#endif //PROYECTO_COLECCIONEQUIPOS_H
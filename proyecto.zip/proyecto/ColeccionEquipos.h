//
// Created by ansat on 23/4/2026.
//

#ifndef PROYECTO_COLECCIONEQUIPOS_H
#define PROYECTO_COLECCIONEQUIPOS_H


class ColeccionEquipos {
};


#endif //PROYECTO_COLECCIONEQUIPOS_H
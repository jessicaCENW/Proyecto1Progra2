#ifndef PROYECTO_MANTENIMIENTO_H
#define PROYECTO_MANTENIMIENTO_H
#include "Equipo.h"
#include "ColeccionEquipos.h"


class Mantenimiento {
private:
    Equipo* aux[3];
public:
    void seleccionar(ColeccionEquipos& b) {
        for (int i=0; i<3; i++) {
            aux[i]=b.getEquipo(i);
        }
    }
    void reparar(ColeccionEquipos& b) {
        for (int i=0; i<3; i++) {
        aux[i]->SetTiempoInactivo(0);
        aux[i]->SetCriticidad(0);
        aux[i]->eliminarIncidencias();
        b.setEquipo(i, aux[i]);
        }
    }


};


#endif //PROYECTO_MANTENIMIENTO_H
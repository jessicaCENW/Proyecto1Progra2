
#ifndef PROYECTO_INCIDENCIA_H
#define PROYECTO_INCIDENCIA_H
#include <random>
using namespace std;


class Incidencia {
private:
    int severidad;
public:
    Incidencia() {
        severidad = 0;
    };
    void generarIncidencia() {
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<> dist(1, 3);

        severidad = dist(gen);
    };

};


#endif //PROYECTO_INCIDENCIA_H
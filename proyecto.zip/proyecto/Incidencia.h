
#ifndef PROYECTO_INCIDENCIA_H
#define PROYECTO_INCIDENCIA_H

#include <string>
using namespace std;

class Equipo;

class Incidencia {
public:

    virtual void gradoIncidencia(Equipo* a) = 0;
    virtual string getTipo() = 0;

};


#endif //PROYECTO_INCIDENCIA_H
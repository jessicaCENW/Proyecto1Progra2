//
// Created by ansat on 29/4/2026.
//

#ifndef PROYECTO_CAMBIOTIEMPO_H
#define PROYECTO_CAMBIOTIEMPO_H
#include "Equipo.h"
#include "CambiarTiempoInactivo.h"
#include "Excepciones.h"


class CambioTiempo {
private:
    CambiarTiempoInactivo* cambio;
public:
    CambioTiempo() {
        cambio=nullptr;
    }
    void setCambio(CambiarTiempoInactivo* cambio) {
        this->cambio = cambio;
    }
    void CambiarTiempo(Equipo& a) {
        if (cambio != nullptr) {
            cambio->cambiarTiempo(a);
        }
        else {
            if (cambio == nullptr) {
                throw ExcepcionStrategy();
            }
        }
    }
};


#endif //PROYECTO_CAMBIOTIEMPO_H
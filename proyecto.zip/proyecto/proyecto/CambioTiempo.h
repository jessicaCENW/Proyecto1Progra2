

#ifndef PROYECTO_CAMBIOTIEMPO_H
#define PROYECTO_CAMBIOTIEMPO_H
#include "Equipo.h"
#include "CambiarTiempoInactivo.h"
#include "Excepciones.h"


class CambioTiempo {
private:
    CambiarTiempoInactivo* cambio;
public:
    CambioTiempo();
    void setCambio(CambiarTiempoInactivo* cambio);
    void CambiarTiempo(Equipo& a);
};


#endif //PROYECTO_CAMBIOTIEMPO_H
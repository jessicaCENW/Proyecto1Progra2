#ifndef PROYECTO_EVENTOSDIARIOS_H
#define PROYECTO_EVENTOSDIARIOS_H
#include "CambiarTiempoInactivo.h"
using namespace std;
#include "Equipo.h"
#include "ColeccionEquipos.h"
#include <vector>
#include <string>
#include <random>
#include "Incidencia.h"
#include "AumentarTiempoInactivo.h"
#include "ResetTiempo.h"
#include "CambioTiempo.h"


class EventosDiarios {
public:
        vector<string> incidenciasDelDia;
        void desgaste(Equipo& a);
        void GenerarIncidencia(Equipo& a);
        void Tiempo(Equipo& a);
        void ordenarcoleccion(ColeccionEquipos& b);
        void mergeSort(ColeccionEquipos& b, int izq, int der);
        void merge(ColeccionEquipos& b, int izq, int medio, int der);

};

#endif //PROYECTO_EVENTOSDIARIOS_H
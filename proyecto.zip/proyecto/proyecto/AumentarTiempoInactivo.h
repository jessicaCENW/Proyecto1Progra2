

#ifndef PROYECTO_AUMENTARTIEMPOINACTIVO_H
#define PROYECTO_AUMENTARTIEMPOINACTIVO_H
#include "CambiarTiempoInactivo.h"
#include "Equipo.h"


class AumentarTiempoInactivo: public CambiarTiempoInactivo {
    public:
        void cambiarTiempo(Equipo& a) override;
};


#endif //PROYECTO_AUMENTARTIEMPOINACTIVO_H
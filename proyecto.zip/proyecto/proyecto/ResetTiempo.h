
#ifndef PROYECTO_RESETTIEMPO_H
#define PROYECTO_RESETTIEMPO_H
#include "CambiarTiempoInactivo.h"
#include "Equipo.h"


class ResetTiempo: public CambiarTiempoInactivo{
    public:
        void cambiarTiempo(Equipo& a) override;
};


#endif //PROYECTO_RESETTIEMPO_H
#ifndef PROYECTO_COLECCIONEQUIPOS_H
#define PROYECTO_COLECCIONEQUIPOS_H
using namespace std;
#include "Equipo.h"
#include <iostream>
#include "Excepciones.h"



class ColeccionEquipos {
private:
    Equipo* equipo[100];
    int cant=0;

public:

    void llenar();
    void setEquipo(int i, Equipo* e);
    Equipo*& getEquipo(int i);
    int getCantidad();
    ~ColeccionEquipos();
    void mostrar();


};


#endif //PROYECTO_COLECCIONEQUIPOS_H
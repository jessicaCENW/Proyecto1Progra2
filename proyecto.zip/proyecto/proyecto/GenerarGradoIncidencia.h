

#ifndef PROYECTO_GENERARGRADOINCIDENCIA_H
#define PROYECTO_GENERARGRADOINCIDENCIA_H
using namespace std;
#include <iostream>
#include "Incidencia.h"
#include "IncidenciaGrave.h"
#include "IncidenciaLeve.h"
#include "IncidenciaMedia.h"
#include <random>


class GenerarGradoIncidencia {
public:
    Incidencia* crearAleatoria();
};


#endif //PROYECTO_GENERARGRADOINCIDENCIA_H

#ifndef PROYECTO_INCIDENCIAGRAVE_H
#define PROYECTO_INCIDENCIAGRAVE_H
#include "Incidencia.h"
#include "Equipo.h"


class IncidenciaGrave: public Incidencia {
public:
    void gradoIncidencia(Equipo* a) override;
    string getTipo() override;
};


#endif //PROYECTO_INCIDENCIAGRAVE_H
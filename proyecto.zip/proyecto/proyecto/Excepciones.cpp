

#include "Excepciones.h"
Excepciones::Excepciones(string m) {
    mensaje = m;
}

const  char* Excepciones::what() const noexcept  {
    return mensaje.c_str();
}


ExcepcionIndice::ExcepcionIndice()
    : Excepciones("Indice fuera de rango") {}

ExcepcionIncidencias::ExcepcionIncidencias()
    : Excepciones("Limite de incidencias alcanzado") {}

ExcepcionStrategy::ExcepcionStrategy()
    : Excepciones("Strategy no definida") {}
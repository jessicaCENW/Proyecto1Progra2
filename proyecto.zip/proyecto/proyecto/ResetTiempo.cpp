

#include "ResetTiempo.h"
void ResetTiempo::cambiarTiempo(Equipo& a) {
    a.SetTiempoInactivo(0);
}
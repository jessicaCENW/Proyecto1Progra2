

#ifndef PROYECTO_INCIDENCIAMEDIA_H
#define PROYECTO_INCIDENCIAMEDIA_H
#include "Equipo.h"
#include "Incidencia.h"


class IncidenciaMedia: public Incidencia {
    public:
    void gradoIncidencia(Equipo* a) override ;
    string getTipo() override;
};


#endif //PROYECTO_INCIDENCIAMEDIA_H
#ifndef PROYECTO_EXCEPCIONES_H
#define PROYECTO_EXCEPCIONES_H
#include <exception>
#include <string>
using namespace std;



class Excepciones : public exception{
protected:
    string mensaje;

public:
    Excepciones(string m);
    const char* what() const noexcept override;

};


class ExcepcionIndice : public Excepciones {
public:
    ExcepcionIndice();
};


class ExcepcionIncidencias : public Excepciones {
public:
    ExcepcionIncidencias();
};


class ExcepcionStrategy : public Excepciones {
public:
    ExcepcionStrategy();
};

#endif


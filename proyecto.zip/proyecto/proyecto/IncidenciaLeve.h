
#ifndef PROYECTO_INCIDENCIALEVE_H
#define PROYECTO_INCIDENCIALEVE_H
#include "Equipo.h"
#include "Incidencia.h"

class IncidenciaLeve: public Incidencia {
public:
    void gradoIncidencia(Equipo* a) override;
    string getTipo() override;
};


#endif //PROYECTO_INCIDENCIALEVE_H


#include "Archivo.h"
 void Archivo:: guardar(string texto, int dia) {

    string nombre = "dia_" + to_string(dia) + ".txt";

    ofstream archivo(nombre);
    archivo << texto;
    archivo.close();
}
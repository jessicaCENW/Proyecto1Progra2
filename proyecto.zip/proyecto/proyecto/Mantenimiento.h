#ifndef PROYECTO_MANTENIMIENTO_H
#define PROYECTO_MANTENIMIENTO_H
#include "Equipo.h"
#include "ColeccionEquipos.h"


class Mantenimiento {
private:
    Equipo* aux[3];
public:
    void seleccionar(ColeccionEquipos& b);
    void reparar(ColeccionEquipos& b);

};


#endif //PROYECTO_MANTENIMIENTO_H
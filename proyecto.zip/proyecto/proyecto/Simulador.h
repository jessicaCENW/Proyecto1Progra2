#ifndef PROYECTO_SIMULADOR_H
#define PROYECTO_SIMULADOR_H
#include "ColeccionEquipos.h"
#include "EventosDiarios.h"
#include "Mantenimiento.h"
#include "ReporteDiario.h"
#include "ReporteAcumulado.h"
#include "Archivo.h"
#include "Excepciones.h"

class Simulador {
public:
    void ejecutar();
};

#endif //PROYECTO_SIMULADOR_H
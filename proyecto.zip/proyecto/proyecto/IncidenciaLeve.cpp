

#include "IncidenciaLeve.h"
void IncidenciaLeve::gradoIncidencia(Equipo* a)  {
    a->aumentarCriticidad(1);
}
string IncidenciaLeve::getTipo()  {
    return "Leve";
}
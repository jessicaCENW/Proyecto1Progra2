

#include "CambioTiempo.h"

CambioTiempo::CambioTiempo() {
    cambio=nullptr;
}
void CambioTiempo::setCambio(CambiarTiempoInactivo* cambio) {
    this->cambio = cambio;
}
void CambioTiempo::CambiarTiempo(Equipo& a) {
    if (cambio != nullptr) {
        cambio->cambiarTiempo(a);
    }
    else {
        if (cambio == nullptr) {
            throw ExcepcionStrategy();
        }
    }
}

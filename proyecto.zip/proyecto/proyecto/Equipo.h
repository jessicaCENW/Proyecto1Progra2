
#ifndef PROYECTO_EQUIPO_H
#define PROYECTO_EQUIPO_H
#pragma once
#include <string>
using namespace std;
#include <iostream>
#include <sstream>

class Incidencia;

class Equipo {
protected:
    int id;
    double criticidad;
    int tiempoInactivo;
    Incidencia* incP[10];
    int contador=0;


public:
    Equipo( int id, double criticidad, int tiempoInactivo);
    Equipo();
    void setId(int id);
    int getId();
    double GetCriticidad();
    void SetCriticidad(double criticidad);
    void aumentarCriticidad(double valor);
    int GetTiempoInactivo();
    void SetTiempoInactivo(int tiempoInactivo);
    int getContador();
    void agregarIncidencia();
    void eliminarIncidencias();
    Incidencia* getIncidencia(int i);
    string incidenciasToString();
    double CalcularPrioridad();
    string tostring();
};


#endif //PROYECTO_EQUIPO_H
#ifndef PROYECTO_ARCHIVO_H
#define PROYECTO_ARCHIVO_H
#include <fstream>
#include <string>
using namespace std;

class Archivo {
public:
    static void guardar(string texto, int dia);
};


#endif //PROYECTO_ARCHIVO_H
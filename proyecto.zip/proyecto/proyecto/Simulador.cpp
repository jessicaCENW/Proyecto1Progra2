

#include "Simulador.h"
void Simulador::ejecutar() {

    ColeccionEquipos equipos;
    equipos.llenar();
    EventosDiarios eventos;
    Mantenimiento mantenimiento;
    ReporteAcumulado acumulado;


    for (int dia = 1; dia <= 30; dia++) {


        for (int i = 0; i < equipos.getCantidad(); i++) {

            try {
                Equipo* e = equipos.getEquipo(i);

                eventos.desgaste(*e);
                eventos.GenerarIncidencia(*e);
                eventos.Tiempo(*e);

            } catch (Excepciones& ex) {
                cout << "Error en equipo " << i
                     << ": " << ex.what() << endl;
            }
        }
        eventos.ordenarcoleccion(equipos);
        ReporteDiario rd(dia, &equipos,eventos.incidenciasDelDia.data(),eventos.incidenciasDelDia.size());
        string texto = rd.generar();
        Archivo::guardar(texto, dia);
        mantenimiento.seleccionar(equipos);
        mantenimiento.reparar(equipos);



        Reporte* r = &acumulado;
        ReporteAcumulado* ac = dynamic_cast<ReporteAcumulado*>(r);

        if (ac != nullptr) {
            ac->agregarDia(texto);
        }


        eventos.incidenciasDelDia.clear();

    }


    ofstream archivo("reporte_final.txt");
    archivo << acumulado.generar();
    archivo.close();
}
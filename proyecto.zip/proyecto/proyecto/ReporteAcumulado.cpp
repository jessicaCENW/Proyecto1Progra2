//
// Created by ansat on 30/4/2026.
//

#include "ReporteAcumulado.h"

void ReporteAcumulado::agregarDia(string texto) {
    if (contador < 30) {
        dias[contador] = texto;
        contador++;
    }
}

string ReporteAcumulado::generar()  {
    stringstream ss;

    ss << "===== REPORTE ACUMULADO =====\n";

    for (int i = 0; i < contador; i++) {
        ss << dias[i] << "\n";
    }

    return ss.str();
}
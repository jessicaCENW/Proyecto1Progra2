

#ifndef PROYECTO_REPORTEACUMULADO_H
#define PROYECTO_REPORTEACUMULADO_H
#pragma once
#include "Reporte.h"
#include <sstream>

class ReporteAcumulado : public Reporte {
private:
    string dias[30];
    int contador = 0;

public:
    void agregarDia(string texto);
    string generar() override ;
};


#endif //PROYECTO_REPORTEACUMULADO_H

#include "IncidenciaMedia.h"
void IncidenciaMedia::gradoIncidencia(Equipo* a)  {
    a->aumentarCriticidad(2);
}
string IncidenciaMedia::getTipo()  {
    return "Media";
}
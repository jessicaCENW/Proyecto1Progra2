//
// Created by ansat on 29/4/2026.
//

#include "Mantenimiento.h"
void Mantenimiento::seleccionar(ColeccionEquipos& b) {
    for (int i=0; i<3; i++) {
        aux[i]=b.getEquipo(i);
    }
}
void Mantenimiento::reparar(ColeccionEquipos& b) {
    for (int i=0; i<3; i++) {
        aux[i]->SetTiempoInactivo(0);
        aux[i]->SetCriticidad(0);
        aux[i]->eliminarIncidencias();
        b.setEquipo(i, aux[i]);
    }
}
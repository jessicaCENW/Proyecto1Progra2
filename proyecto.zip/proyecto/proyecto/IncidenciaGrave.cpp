
#include "IncidenciaGrave.h"
void IncidenciaGrave::gradoIncidencia(Equipo* a)  {
    a->aumentarCriticidad(3);
}
string IncidenciaGrave::getTipo()  {
    return "Grave";
}

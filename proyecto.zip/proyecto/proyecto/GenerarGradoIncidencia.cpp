
#include "GenerarGradoIncidencia.h"
Incidencia* GenerarGradoIncidencia::crearAleatoria() {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist(1, 3);
    int aux = dist(gen);
    if (aux == 1) return new IncidenciaLeve();
    if (aux == 2) return new IncidenciaMedia();
    return new IncidenciaGrave();
}


#include "AumentarTiempoInactivo.h"
void AumentarTiempoInactivo::cambiarTiempo(Equipo &a) {
    a.SetTiempoInactivo(a.GetTiempoInactivo() + 1);
}

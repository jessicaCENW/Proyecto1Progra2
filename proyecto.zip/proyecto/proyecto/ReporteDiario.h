#ifndef PROYECTO_REPORTEDIARIO_H
#define PROYECTO_REPORTEDIARIO_H
#pragma once
#include "Reporte.h"
#include "ColeccionEquipos.h"
#include <sstream>

class ReporteDiario : public Reporte {
private:
    int dia;
    ColeccionEquipos* equipos;
    string* incidencias;
    int cantidadIncidencias;


public:
    ReporteDiario(int d, ColeccionEquipos* eq, string inc[], int cant);
    string generar() override;

};

#endif //PROYECTO_REPORTEDIARIO_H
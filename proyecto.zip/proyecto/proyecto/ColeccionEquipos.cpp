

#include "ColeccionEquipos.h"

void ColeccionEquipos::llenar() {
    for (int i=0; i<100; i++) {
        equipo[i]=new Equipo();
        equipo[i]->setId(i+1);
        cant++;
    }
}
void ColeccionEquipos::setEquipo(int i, Equipo* e) {
    equipo[i]=e;
}
Equipo*& ColeccionEquipos::getEquipo(int i) {
    if (i < 0 || i >= cant) {
        throw ExcepcionIndice();
    }
    return equipo[i];
}
int ColeccionEquipos::getCantidad() {
    return cant;
}
ColeccionEquipos::~ColeccionEquipos() {
    for (int i = 0; i < cant; i++) {
        delete equipo[i];
    }
}
void ColeccionEquipos::mostrar() {
    for (int i=0; i<100; i++) {
        cout<<equipo[i]->tostring()<<endl;
    }
}

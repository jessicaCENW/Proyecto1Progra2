

#ifndef PROYECTO_GENERARGRADOINCIDENCIA_H
#define PROYECTO_GENERARGRADOINCIDENCIA_H
using namespace std;
#include "Incidencia.h"
#include "IncidenciaGrave.h"
#include "IncidenciaLeve.h"
#include "IncidenciaMedia.h"
#include <random>


class GenerarGradoIncidencia {
public:
    Incidencia* crearAleatoria() {
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<> dist(1, 3);

        int aux = dist(gen);

        if (aux == 1) return new IncidenciaLeve();
        if (aux == 2) return new IncidenciaMedia();
        return new IncidenciaGrave();
    }
};


#endif //PROYECTO_GENERARGRADOINCIDENCIA_H
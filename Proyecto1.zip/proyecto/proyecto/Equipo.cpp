#include "Equipo.h"
#include "GenerarGradoIncidencia.h"
#include "Excepciones.h"


Equipo::Equipo( int id, double criticidad, int tiempoInactivo) {
    this->id = id;
    this->criticidad = criticidad;
    this->tiempoInactivo = tiempoInactivo;

}

Equipo::Equipo()
{
    this->id =0;
    this->criticidad = 0;
    this->tiempoInactivo = 0;

}


void Equipo::setId(int id) {
    this->id = id;
}
int Equipo::getId() {
    return id;
}
double Equipo::GetCriticidad() {
    return criticidad;
}
void Equipo::SetCriticidad(double criticidad) {
    this->criticidad = criticidad;
}

void Equipo::aumentarCriticidad(double valor) {
    criticidad += valor;
}
int Equipo::GetTiempoInactivo() {
    return tiempoInactivo;
}
void Equipo::SetTiempoInactivo(int tiempoInactivo) {
    this->tiempoInactivo = tiempoInactivo;
}

int Equipo::getContador() {
    return contador;
}

void Equipo::agregarIncidencia() {
    if (contador < 10) {
        GenerarGradoIncidencia generador;
        Incidencia* nueva = generador.crearAleatoria();
        nueva->gradoIncidencia(this);
        incP[contador] = nueva;
        contador++;
    }
    else {
        throw ExcepcionIncidencias();
    }
}
void Equipo::eliminarIncidencias() {

        for (int i = contador - 1; i >= 0; i--) {
            delete incP[i];
            incP[i] = nullptr;
        }
        contador = 0;

}
Incidencia* Equipo::getIncidencia(int i) {
    return incP[i];
}

string Equipo::incidenciasToString() {
    string resultado = "";

    for (int i = 0; i < contador; i++) {
        resultado += incP[i]->getTipo();

        if (i < contador - 1) {
            resultado += ", ";
        }
    }

    if (resultado == "") {
        resultado = "Sin incidencias";
    }

    return resultado;
}

double Equipo::CalcularPrioridad() {
    return (tiempoInactivo*0.2)+(criticidad*0.5)+(contador*0.3);
}

string Equipo::tostring() {
    stringstream ss;
    ss<<id<<endl;
    ss<<criticidad<<endl;
    ss<<tiempoInactivo<<endl;
    return ss.str();
}

#include "Simulador.h"
#include <iostream>
using namespace std;

void Simulador::ejecutar() {

    ColeccionEquipos equipos;
    equipos.llenar();
    EventosDiarios eventos;
    Mantenimiento mantenimiento;
    ReporteAcumulado acumulado;

    for (int dia = 1; dia <= 30; dia++) {

        for (int i = 0; i < equipos.getCantidad(); i++) {
            try {
                Equipo* e = equipos.getEquipo(i);
                eventos.desgaste(*e);
                eventos.GenerarIncidencia(*e);
                eventos.Tiempo(*e);
            } catch (Excepciones& ex) {
                cout << "Error en equipo " << i
                     << ": " << ex.what() << endl;
            }
        }

        eventos.ordenarcoleccion(equipos);

        Equipo* topEquipo = equipos.getEquipo(0);
        int idTop = topEquipo->getId();

        ReporteDiario rd(dia, &equipos, eventos.incidenciasDelDia.data(),
                         eventos.incidenciasDelDia.size());
        string texto = rd.generar();

        // Salida en consola formato enunciado
        cout << "Top prioridad: ";
        for (int i = 0; i < 3; i++) {
            Equipo* e = equipos.getEquipo(i);
            cout << "EQ-" << e->getId()
                 << " (" << e->CalcularPrioridad() << ")";
            if (i < 2) cout << ", ";
        }
        cout << "\n";
        cout << "Asignados: ";
        for (int i = 0; i < 3; i++) {
            cout << "EQ-" << equipos.getEquipo(i)->getId();
            if (i < 2) cout << ", ";
        }
        cout << "\n";
        cout << "Backlog pendiente: " << (equipos.getCantidad() - 3) << "\n";
        cout << "Riesgo global: " << rd.calcularRiesgoGlobal() << "\n";
        cout << "---------------------------\n";

        Archivo::guardar(texto, dia);

        mantenimiento.seleccionar(equipos);
        mantenimiento.reparar(equipos);

        Reporte* r = &acumulado;
        ReporteAcumulado* ac = dynamic_cast<ReporteAcumulado*>(r);
        if (ac != nullptr) {
            ac->agregarDia(texto);
        }

        eventos.incidenciasDelDia.clear();
        int pos = equipos.buscarPorId(idTop);

        if (pos != -1) {
            cout << "--Busqueda binaria--"
                 << "Dia " << dia
                 << " | Equipo critico ID " << idTop
                 << " encontrado en posicion [" << pos << "]"
                 << " | Prioridad: " << topEquipo->CalcularPrioridad()
                 << endl;
        }

    }

    ofstream archivo("reporte_final.txt");
    archivo << acumulado.generar();
    archivo.close();
}

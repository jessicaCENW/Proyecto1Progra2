

#include "ColeccionEquipos.h"

void ColeccionEquipos::llenar() {
    for (int i=0; i<100; i++) {
        equipo[i]=new Equipo();
        equipo[i]->setId(i+1);
        cant++;
    }
}
void ColeccionEquipos::setEquipo(int i, Equipo* e) {
    equipo[i]=e;
}
Equipo*& ColeccionEquipos::getEquipo(int i) {
    if (i < 0 || i >= cant) {
        throw ExcepcionIndice();
    }
    return equipo[i];
}
int ColeccionEquipos::getCantidad() {
    return cant;
}
ColeccionEquipos::~ColeccionEquipos() {
    for (int i = 0; i < cant; i++) {
        delete equipo[i];
    }
}
void ColeccionEquipos::mostrar() {
    for (int i=0; i<100; i++) {
        cout<<equipo[i]->tostring()<<endl;
    }
}
int ColeccionEquipos::buscarPorId(int id){
    int indices[100];
    for (int i = 0; i < cant; i++) {
        indices[i] = i;
    }

    // Ordenar indices por el ID del equipo al que apuntan
    for (int i = 1; i < cant; i++) {
        int key = indices[i];
        int keyId = equipo[key]->getId();
        int j = i - 1;
        while (j >= 0 && equipo[indices[j]]->getId() > keyId) {
            indices[j + 1] = indices[j];
            j--;
        }
        indices[j + 1] = key;
    }

    // Paso 2: busqueda binaria sobre los indices ordenados por ID
    int izq = 0;
    int der = cant - 1;

    while (izq <= der) {
        int medio = (izq + der) / 2;
        int idMedio = equipo[indices[medio]]->getId();

        if (idMedio == id) {
            return indices[medio];   // retorna posicion real en el arreglo
        } else if (idMedio < id) {
            izq = medio + 1;
        } else {
            der = medio - 1;
        }
    }

    return -1;  // no encontrado
    }